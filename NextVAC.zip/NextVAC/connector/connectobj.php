<?php
    require_once $_SERVER['DOCUMENT_ROOT'].'/connector/database.php';
   try{
       $connect=new PDO("mysql:host=$host;dbname=$dbname",$username,$password);
       $connect->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
   }
   catch(PDOException $e){
        echo 'Connect Object Error:'.$e->getmessage();
   } 
?>