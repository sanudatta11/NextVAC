<?php

//Setting session pathinfo


//Call database files
require_once $_SERVER['DOCUMENT_ROOT'].'/connector/connectobj.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/connector/database.php';

if(isset($_POST['lg_username'])&&isset($_POST['lg_password']))
{
    $user=$_POST['lg_username'];
    $pass=$_POST['lg_password'];

    //sql querry
    /*
    $sql_q="SELECT * FROM login_table WHERE username=".$user;
    $temp=$connect->query($sql_q);
    $row=$temp->fetch(PDO::FETC_ASSOC);
    */

    $connectobj=$connect->prepare('SELECT * FROM login_table');
    $connectobj->execute();
    $connectobj->setFetchMode(PDO::FETCH_ASSOC);

    $flag=0;

    while($checklogin=$connectobj->fetch())
    {
    //Check
            if($checklogin['username']==$user)
            {
                echo "<script>
                console.log('Hello in user');
                    </script>";
                if($checklogin['password']==$pass)
                {
                    $flag=1;
                    $print=$checklogin['username'];
                    echo "
                    <script>
                        window.alert('Welcome User');
                        window.location.href= '/succ.php';
                    </script>
                    ";
                }
                else
                {
                    echo "<script>
                            window.alert('Wrong username and password');
                            console.log('In 2nd');
                            window.location.href='/';   
                         </script>";
                }
            }
    }
            echo "<script>
                    window.alert('Wrong username and password');
                    console.log('In 2nd');
                    window.location.href='/';   
                    </script>";
    $connect->close();   
}
?>
