<?php
    $allowkey="allowitasshole";
    $disallowkey="dontallowasshole";
?>