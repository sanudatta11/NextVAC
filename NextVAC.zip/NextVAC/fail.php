<html>
<head>
    <title>loged page</title>
</head>
<body>
    <script type="text/javascript">
        alert('Username and Password was not entered correctly')
    </script>
    <h1>fail page</h1>
</body>
</html>
