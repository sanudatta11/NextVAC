<html>
<?php
    session_destroy();
    session_unset();
?>
<head>
    <title>Login</title>
    <!-- All the files that are required -->
    <link rel="stylesheet" href="main.css">
    <link href='font.css' rel="stylesheet" type="text/css">
    <script src="main_js.js"></script>
    <script>
        var name;

        function change_drop(name) {
            var but = document.getElementById('choose_id');
            but.value = name;
        }

    </script>
</head>

<body>
    <div class="text-center" style="padding:50px 0">
        <div class="logo">Next VAC</div>
        <!-- Main Form -->
        <div class="login-form-1">
            <form id="login-form" role="form" class="text-left" action="login.php" method="POST">
                <div class="login-form-main-message"></div>
                <div class="main-login-form">
                    <div class="login-group">
                        <div class="form-group">
                            <label for="lg_username" class="sr-only">Username</label>
                            <input type="text" class="form-control" id="lg_username" name="lg_username" placeholder="username" required>
                        </div>
                        <div class="form-group">
                            <label for="lg_password" class="sr-only">Password</label>
                            <input type="password" class="form-control" id="lg_password" name="lg_password" placeholder="password" required>
                        </div>
                        <br>
                        <div class="dropdown" name="drop">
                            <input class="drop-btn" id="choose_id" value="Choose" type="button"></input>
                            <div class="drop-btn-content">
                                <a href="#" id="vid" onclick="change_drop('Video Lecture')">Video Lecture</a><br>
                                <a href="#" id="mcq" onclick="change_drop('Attempt MCQ')">Attempt MCQ</a><br>
                                <a href="#" id="plat" onclick="change_drop('Coding IDE')">Coding IDE</a>
                                <a href="#" id="net" onclick="change_drop('Uninetwork')">Uninetwork</a>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="login-button"><i class="fa fa-chevron-right"></i></button>
                </div>

            </form>
            <div class="etc-login-form">
                    <p id="one">Forgot your password? <a href="#">click here</a></p>
                    <p id="one1">New user ? <a href="/makeuser/make.php">Register Here</a></p>
            </div>
        </div>
        <!-- end:Main Form -->
    </div>
</body>

</html>
