#include<iostream>
using namespace std;
int main()
{
    int n,m,c;
    cin>>n>>m>>c;
    cout<<n<<"\n"<<m<<"\n"<<c+1;
    while(1)
    cout<<"Jinkies Man";
    return 0;
}

//Now am changing the output for your satisfaction

//This verifies the output with my provided one which is the three numbers I have taken
//as input with every one in new line.

//I will remove the new line now and it will be wrong

//Files are not identical ...F1 F2 for debugging ..ignore...so thats it bro