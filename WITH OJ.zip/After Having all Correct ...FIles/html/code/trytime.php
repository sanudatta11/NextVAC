<?php
    $arr_out=array();
    $retst=-1;
    $output=exec("timeout 2 sleep 11",$arr_out,$retst);
    echo $retst;
 ?>


//If timeout is called then it will provide 124 status request and if it wl not timeout
//Then it will provide a 0 status message
