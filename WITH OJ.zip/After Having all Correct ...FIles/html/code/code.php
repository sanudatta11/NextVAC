<!DOCTYPE html>
<!DOCTYPE HTML>

<html>
  <head>
    <meta charset="utf-8">
    <title>Code Editor</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="change_back.js" rel="text/javascript"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script src="change_lang.js" rel="text/javascript"></script>
    <script src="ace/src-noconflict/ace.js" type="text/javascript" charset="utf-8"></script>
    <script src="ace/src-noconflict/ext-language_tools.js"></script>
    <script src="copyace.js" type="text/javascript"></script>

    <script>
        function checkme() {
            var val = editor.getValue();
            document.getElementById('code_arena').value = editor.getValue();
            console.log(val);
        }
    </script>



    <link rel="stylesheet" href="code_snip.css">

  </head>

<!--Body starts here-->

  <body>
    <nav class="navbar navbar-inverse">
      <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#" id="poplu">NextVAC</a>
    </div>
    <ul class="nav navbar-nav" id ="poplu">
      <li class="active"><a href="#">Problems</a></li>
      <li><a href="#">Code Editor</a></li>
      <li><a href="#">Obtained Marks</a></li>
      <li><a href="#">Leaderboard</a></li>
    </ul>
    <button class="btn btn-danger navbar-btn" id="logout">Log Out</button>
    </div>
  </nav>

  <!--Left Nabbar-->
<div class="container">
    <div class="row_profile" id="row">
		<div class="col-md-3">
			<div class="profile-sidebar">
				<!-- SIDEBAR USERPIC -->
				<div class="profile-userpic">
					<img src="mark.jpg" class="img-responsive" alt="logo">
				</div>
				<!-- END SIDEBAR USERPIC -->
				<!-- SIDEBAR USER TITLE -->
				<div class="profile-usertitle">
					<div class="profile-usertitle-name">
						Soumyajit Dutta
					</div>
					<div class="profile-usertitle-job">
						Developer and Coder
					</div>
				</div>
				<!-- END SIDEBAR USER TITLE -->
				<!-- SIDEBAR BUTTONS -->
				<div class="profile-userbuttons">
					<button type="button" class="btn btn-success btn-sm">Follow</button>
					<button type="button" class="btn btn-danger btn-sm">Message</button>
				</div>
				<!-- END SIDEBAR BUTTONS -->
				<!-- SIDEBAR MENU -->
				<div class="profile-usermenu">
					<ul class="nav">
            <li class="active">
              <a href="#">
                <i class="glyphicon glyphicon-pencil"></i>
                Coding Ground
              </a>
            </li>
						<li class>
							<a href="#">
							<i class="glyphicon glyphicon-home"></i>
							UniNetwork </a>
						</li>
						<li>
							<a href="#">
							<i class="glyphicon glyphicon-facetime-video"></i>
							    Video Lecture</a>
						</li>
						<li>
							<a href="#" target="_blank" id="test">
							<i class="glyphicon glyphicon-ok"></i>
							Attempt Live Test  </a>
						</li>
						<li>
							<a href="#">
							<i class="glyphicon glyphicon-folder-open"></i>
							 File Sharing</a>
						</li>
            <li>
              <a href="#">
                <i class="glyphicon glyphicon-cog">
                  Settings
                </i>
              </a>
            </li>
					</ul>
				</div>
				<!-- END MENU -->
			</div>
		</div>
	</div>
<!--End of side bar-->

<!--Start of Question Tags-->
<div class="rank_bar">
  <ul class="rank_ul">
    <li class="section_li"><a href="#">Section:K1611</a></li>
    <li><a href="#">Points:2044</a></li>
    <li><a href="#">Rank:36,345</a></li>
  </ul>
</div>

<div class="ques_tag">
  <h2>Solve me First</h2>
</div>
<br />
<div class="ques_full">
  <p class="full_ques">
      Welcome to NextVAC! The purpose of this challenge is to familiarize you with reading input from stdin (the standard input stream) and writing output to stdout (the standard output stream) using our environment. <br /><br />
      Review the code provided in the editor below, then complete the solveMeFirst function so that it returns the sum of two integers read from stdin. Take some time to understand this code so you're prepared to write it yourself in future challenges.<br /><br />
      Select a language below, and start coding!<br />
  </p>
  <br />
  <strong id="input_start">Input</strong>
  <p class="input_q">
    Code that reads input from stdin is provided for you in the editor. There are lines of input, and each line contains a single integer.<br />
  </p>
  <br />
  <strong id="output_start">Output</strong>
  <p class="output_q">
    Code that prints the sum calculated and returned by solveMeFirst is provided for you in the editor.<br />
  </p>
</div>
<form action="submitcode.php" method="post" class="code_form">
<div class="code-it">
<label for="comment" style="margin:10px;">Code Here:</label>
<br /><br />
<!--Language Selector-->
<div class="dropup" style="float:right;display:inline-block;">
  <button class="btn btn-default dropdown-toggle" type="button" id="lang-but" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" name="lang-but">
    Language
    <span class="caret"></span>
  </button>
  <ul class="dropdown-menu" aria-labelledby="dropdownMenu2">
    <li id="lang_c"><a href="#" onclick="change_drop('C',1)">C</a></li>
    <li id="lang_c++"><a href="#" onclick="change_drop('C++',2)">C++</a></li>
    <li id="lang_py"><a href="#" onclick="change_drop('Python',3)">Python</a></li>
    <!-- <li role="separator" class="divider"></li>
    <li id="lang_bash"><a href="#"  onclick="change_drop('BASH')">BASH</a></li> -->
  </ul>
  <button class="btn btn-primary active" id="submit-bt" type="submit" style="display:inline-flex;">Submit</button>
</div>
</div>
<br /><br />
<!--The main coding arena fucker-->

  <div class="code-form" style="margin-left: 37px;margin-top:30px; margin-bottom:200px;min-height: 360px;">
   <textarea class="form-control" style="display:none" id="code_arena" name="code_arena"></textarea>
   <div id="editor" class="editor">
   </div>
     <script src="ace_required.js" type="text/javascript" charset="utf-8"></script>

  </div>

</form>


</div>      <!--This is the end of the whole container tag-->

<br>
<br>

</body>
</html>
