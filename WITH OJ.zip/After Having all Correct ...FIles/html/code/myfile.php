
	<?php
	// Open the text file
	$f = fopen("/home/stuxnet/Documents/textfile.txt", "w");

  if(!$f)
    echo "<script>alert('Not opening file')</script>";

	// Write text
	fwrite($f, $_POST["code_arena"]);

	// Close the text file
	fclose($f);

	// Open file for reading, and read the line
	$f = fopen("textfile.txt", "r");

	// Read text
	echo fgets($f);
	fclose($f);

	?>
