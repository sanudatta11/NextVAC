<?php
        $seconds = 2;
        set_time_limit($seconds);
        ini_set('max_execution_time',2);
        //echo "hi";
        if($_POST["code_arena"])
        {
          $fi = fopen("codetemp.cpp", "w");
          if(!$fi)
            echo "<script>alert('Not opening file')</script>";
          // Write text
          fwrite($fi,$_POST["code_arena"]);
          fclose($fi);

          /*
          echo "
          <script>
              window.alert('Code Submitted');
              window.location.href= '/code/code.php';
          </script>
          ";*/
          a:
          $cmd = "g++ codetemp.cpp -o codetemp1.o 2>&1";
          $error=shell_exec($cmd);

          if(!(isset($error)))
          {
            //echo "2";
            $cmd_sec="./codetemp1.o <  inp.txt";
            $output=shell_exec($cmd_sec);
            if(!(isset($output)))
              {
                sleep(1);
                goto a;
              }
              $tle=0;
              shell_exec("rm codetemp1.o");
          }
          else {
            //echo "3";
            $tle=0;
            echo $error;
          }
          shell_exec("rm codetemp1.o");

        }
        else {
          $tle=0;
          echo "
          <script>
              window.alert('Code is Blank');
              window.location.href= '/code/code.php';
          </script>
          ";
        }
?>
