<?php
  $tle=1;
?>


<?php
        $seconds = 1;
        set_time_limit($seconds);
        if($_POST["code_arena"])
        {
          $fi = fopen("codetemp.cpp", "w");
          if(!$fi)
            echo "<script>alert('Not opening file')</script>";
          // Write text
          fwrite($fi,$_POST["code_arena"]);
          fclose($fi);
          $cmd = "g++ codetemp.cpp -o codetemp1.o 2>&1";
          $error=shell_exec($cmd);

          if(!(isset($error)))
          {
            //echo "2";
            $cmd_sec="./codetemp1.o <  inp.txt > output.txt";
            $command="timeout ".$seconds." ".$cmd_sec;
            //fwrite($fout,shell_exec($command));
            shell_exec($command);
            //fclose($fout);
            $tle=0;
            $file_size=0;
            $file_size=filesize("output.txt");
            if($file_size>2000000)
            {  $tle=1;
              shell_exec("rm output.txt");
              shell_exec("rm codetemp1.o");
            }
            else
            {
                $ret_stat=-1;
                exec($command,$output,$ret_stat);
                if($ret_stat==124)
                  {
                    $tle=1;
                    shell_exec("rm codetemp1.o");
                    shell_exec("rm output.txt");
                  }
                else
                  {
                      $tle=0;
                      $f_main=fopen("output.txt","r");
                      $f_test=fopen("test_out.txt","r");
                      if(!$f_main||!$f_test)
                        echo "<script>Error opening files</script>";
                      $same=true;
                      $did=0;
                      $time=0;
                      $mainchar=fgetc($f_main);
                      $testchar=fgetc($f_test);
                      while(!feof($f_main)&&!feof($f_test))
                      {
                        if($mainchar!=$testchar)
                        {
                          //  echo "<br />F1:".$mainchar;
                          //  echo "<br />F2:".$testchar;
                           $same=false;
                           $did=1;
                           break;
                        }
                        else {
                            // echo "<br />".$mainchar;
                            // echo "<br />".$testchar;
                            $same=true;
                          }
                        $mainchar=fgetc($f_main);
                        $testchar=fgetc($f_test);
                      }
                      $ch=fgetc($f_test);
                      //echo "Start ".feof($f_main)."---".feof($f_test)."=".$time;
                      if(feof($f_main)&&feof($f_test))
                        {
                          if($did)
                             $same=false;
                          else
                             $same=true;
                        }
                      else {
                        // if(feof($f_main))
                        //   echo "1 ended";
                        // if(feof($f_test))
                        //   echo "2 ended";
                        // echo "c=".feof($f_main)."=";
                        $same=false;
                      }
                      fclose($f_main);
                      fclose($f_test);
                      // echo "<br />"
                      // echo sha1_file("test_out.txt");
                      if($same==true)
                        echo "<br /> Correct Answer";
                      else
                        echo "<br />Wrong Answer";

                    //Do anything below you want for the Fucking output.

                       shell_exec("rm codetemp1.o");
                }
          }
          }
          else {
            //echo "3";
            $tle=-1;
            echo $error;
          }

        }
        else {
          $tle=0;
          echo "
          <script>
              window.alert('Code is Blank');
              window.location.href= '/code/code.php';
          </script>
          ";
        }
?>


<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Judged output</title>
  </head>
  <body>
    <p>
      Verdict:
      <?php
       if($tle==1)
        echo"TLE:Time Limit Exceeded";
       else if($tle==-1)
        echo "Compile Error";
       else
         echo "Output Generated";
       ?>
    </p>
  </body>
</html>
