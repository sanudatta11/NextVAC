$(document).ready(function() {
      $('#logout').css("background-color","green");
      $('#logout').hover(function() {
        /* Stuff to do when the mouse enters the element */
        $('ul').css("opacity",'0.5');
        $('.container').css("opacity",'0.5');
        $('#logout').css('opacity','1');
        $('#poplu').css('color','white');
        $('.navbar-header').css('font-size','50px');
      //  $('.container').hide('fast');
      }, function() {
          $('ul').css('opacity','1');
          $('#poplu').css('color','grey');
        //  $('.container').show();
          $('.container').css("opacity",'1');
        /* Stuff to do when the mouse leaves the element */
      });
});
