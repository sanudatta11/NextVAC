$('document').ready(function(){

  $('#submit-bt').hover(function() {
    /* Stuff to do when the mouse enters the element */
    var val1=editor.getValue();
    var textarea_obj=document.getElementById('code_arena');
    textarea_obj.value=val1;
    console.log(val1);
  }, function() {
    /* Stuff to do when the mouse leaves the element */
  });
});
