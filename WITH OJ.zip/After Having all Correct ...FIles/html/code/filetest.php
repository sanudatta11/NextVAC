<html>
	<head>
	<title>Write to a text file</title>
	</head>
	<body>

	<h1>Adding a text block to a text file:</h1>
	<form action="myfile.php" method='post'>
	<textarea name='textblock'></textarea>
	<input type='submit' value='Add text'>
	</form>

	</body>

	</html>
