//Javascript code for choosing the language

var name,num;
// var lang,num;

function change_drop(name,num) {
    var but = document.getElementById('lang-but');
    but.innerHTML = name;
    but.value = name;

    switch (num) {
      case 1:
      case 2:    editor.getSession().setMode("ace/mode/c_cpp");
                      break;
      case 3:  editor.getSession().setMode("ace/mode/python");
                      break;
      default: editor.getSession().setMode("ace/mode/javascript");
    }

}
