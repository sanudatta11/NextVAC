
    var editor = ace.edit('editor');
    editor.setTheme("ace/theme/eclipse");
    editor.setValue("Code Here");
    editor.getSession().setMode("ace/mode/c_cpp");


        // trigger extension
        ace.require("ace/ext/language_tools");
        editor.session.setMode("ace/mode/c_cpp");
        // enable autocompletion and snippets

        editor.setOptions({
            enableBasicAutocompletion: true,
            enableSnippets: true,
            enableLiveAutocompletion: true
        });
