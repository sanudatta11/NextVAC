<?php
    $host="127.0.0.1:3306";
    $dbname="login_db";
    $username="stuxnet_db";
    $password="abcd123#*";
    $tbname="login_table";
?>