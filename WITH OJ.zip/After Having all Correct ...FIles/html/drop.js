function change_drop(name) {
    documen.getElementById('choose_id').value = name;
    documnent.write(name);
}