<?php
    header('Location: /');
?>