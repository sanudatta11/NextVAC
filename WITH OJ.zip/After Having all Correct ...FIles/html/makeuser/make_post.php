<?php

//Call database files
require_once $_SERVER['DOCUMENT_ROOT'].'/connector/connectobj.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/connector/database.php';

$tempuser=$_POST['m_username'];
$temppass=$_POST['m_password'];

if(isset($tempuser) && isset($temppass))
{
    //$sqlcomm='INSERT INTO login_table (username,password) VALUES ('.$tempuser.','.$temppass.')';
   // $connect->exec($sqlcomm);
    
    //add user
    $add_obj=$connect->prepare('INSERT INTO login_table (username,password) VALUES (:user_t,:pass_t)');
    $add_obj->bindParam(':user_t',$tempuser);
    $add_obj->bindParam(':pass_t',$temppass);
    if($add_obj->execute())
    {
    echo "<script>
    window.alert('New user added');
    console.log('User added');
    window.location.href = '/makeuser/make.php';
    </script>";
    }
    else
    {
         echo "<script>
    window.alert('Error User not added');
    console.log('User not added');
    window.location.href = '/makeuser/make.php';
    </script>";
    }
}
else
{
    echo "
        <script>
            window.alert('Unauthorized Access');
            window.location.href = '/makeuser/make.php';    
        </script>
    ";
}
$connect->close();
?>
