<!DOCTYPE HTML>
<!DOCTYPE html>
<html>
<?php
    require_once $_SERVER['DOCUMENT_ROOT'].'/makeuser/keys.php';
    session_start();
    $_SESSION['admin']=hash('sha1',$disallowkey);
?>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="main.css">
    <link href='font.css' rel="stylesheet" type="text/css">
    <script src="main_js.js"></script>
    <title>Master</title>
</head>

<body>
    <script language="javascript">
        var user_j = prompt("Enter Admin Username");
        var pass_j = prompt("Enter Admin Password");
        var actual_u='stuxnet';
        var actual_p='stux';
        if (!(user_j == actual_u && pass_j == actual_p)) {
            window.alert('Wrong Admin Credentials');
            window.location.href = "/";
        }
        else{
            <?php
            $_SESSION['admin']=hash('sha1',$allowkey);
        ?>
        }
    </script>
<?php
    $temp_key=$_SESSION['admin'];
    if(hash('sha1',$allowkey)!=$temp_key)
        {
            echo "
            <script>
                window.alert('Unauthorized Session Access');
                window.location.href = '/';
            </script>
            ";
        }
?>
    <div class="text-center" style="padding:50px 0">
        <div class="logo">Next VAC Master</div>
        <!-- Main Form -->
        <div class="login-form-1">
            <form id="login-form" role="form" class="text-left" action="make_post.php" method="POST">
                <div class="login-form-main-message"></div>
                <div class="main-login-form">
                    <div class="login-group">
                        <div class="form-group">
                            <label for="m_username" class="sr-only">Username</label>
                            <input type="text" class="form-control" id="m_username" name="m_username" placeholder="New Username" required>
                        </div>
                        <div class="form-group">
                            <label for="m_password" class="sr-only">Password</label>
                            <input type="password" class="form-control" id="m_password" name="m_password" placeholder="New Password" required>
                        </div>
                    </div>
                    <button type="submit" class="login-button"><i class="fa fa-chevron-right"></i></button>
                </div>
        </div>
        <div class="etc-login-form" id="return_back">
            <p>Want to Login?<a href="redirect_back.php">Click Here</a></p>
        </div>
        </form>
    </div>
    <!-- end:Main Form -->
    </div>
</body>

</html>